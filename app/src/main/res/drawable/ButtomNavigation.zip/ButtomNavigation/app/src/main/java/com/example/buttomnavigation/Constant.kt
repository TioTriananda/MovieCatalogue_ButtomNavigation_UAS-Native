package com.example.buttomnavigation

const val IMAGE_BASE = "https://image.tmdb.org/t/p/w500/"

